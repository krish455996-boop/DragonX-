# DragonX — Cloud APK Project

This project wraps the supplied DragonX HTML file in an Android WebView.

## Build in the cloud with GitHub

1. Create a new GitHub repository.
2. Upload all files/folders from this project.
3. Push to the `main` branch.
4. Open the repository's **Actions** tab.
5. Open **Build DragonX APK**.
6. Download the `DragonX-debug-apk` artifact after the workflow finishes.
7. Extract the artifact and install `app-debug.apk` on Android.

You can also start the workflow manually from **Actions → Build DragonX APK → Run workflow**.

The original HTML is stored at:
`app/src/main/assets/index.html`

The WebView enables JavaScript, DOM storage, cookies, media playback, and Internet access so the existing HTML can use its web-based resources and iframe section.
